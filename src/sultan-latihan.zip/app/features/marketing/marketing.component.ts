import { CurrencyPipe, DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, signal } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

export interface DocumentItem {
  id: number;
  documentType: string;
  documentName: string;
  documentUrl: string;
  uploadedAt: string;
}

export interface MarketingLoanApplicationItem {
  id: number;
  loanApplicationNo: string;
  branchCode: string;
  branchName: string;

  // Profil Data Diri Konsumen (16 Fields Grid 4x4)
  customerName: string;
  customerNik: string;
  customerPhone: string;
  customerEmail: string;
  province: string;
  city: string;
  domicileAddress: string;
  motherMaidenName: string;
  occupation: string;
  jobPosition: string;
  businessSector: string;
  companyName: string;
  monthlyIncome: number;
  fundSource: string;
  companyPhone: string;
  companyAddress: string;

  // Detail Pengajuan Pinjaman Terstruktur
  productName: string;
  tenorMonths: number;
  maxPlafondLimit: number;
  requestedAmount: number;
  approvedAmount: number;
  remainingLimit: number;

  // Bank & Logo
  bankName: string;
  bankLogoUrl: string;
  accountNumber: string;
  accountHolderName: string;
  statusCode: string;
  statusName: string;
  createdAt: string;
  documents: DocumentItem[];
}

@Component({
  selector: 'app-marketing-queue',
  standalone: true,
  imports: [CurrencyPipe, DatePipe, FormsModule, ReactiveFormsModule],
  templateUrl: './marketing.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MarketingQueueComponent {
  // Mode Tampilan Halaman: 'table' atau 'detail' (Berdiri sendiri)
  readonly viewMode = signal<'table' | 'detail'>('table');

  readonly currentBranch = signal('JAKARTA');
  readonly searchQuery = signal('');
  readonly selectedStatusFilter = signal<string>('ALL');

  // Dual Calendar Range Picker States
  readonly isDatePickerOpen = signal(false);
  readonly selectedStartDate = signal<Date | null>(null);
  readonly selectedEndDate = signal<Date | null>(null);
  readonly currentCalendarDate = signal<Date>(new Date(2026, 8, 1));

  // Pagination States
  readonly currentPage = signal<number>(1);
  readonly pageSize = signal<number>(5);
  readonly pageSizeOptions = signal<number[]>([5, 10, 20, 30, 50, 100]);

  // Selected Detail Item & Document State
  readonly selectedDetailItem = signal<MarketingLoanApplicationItem | null>(null);
  readonly previewDocument = signal<DocumentItem | null>(null);

  // State Modal Form Action Keputusan
  readonly isActionModalOpen = signal(false);
  readonly currentAction = signal<'APPROVE' | 'REJECT' | 'REQUEST_ADDITIONAL_DATA' | null>(null);
  readonly isSubmitting = signal(false);

  readonly reviewForm: FormGroup;

  readonly queueItems = signal<MarketingLoanApplicationItem[]>([
    {
      id: 101,
      loanApplicationNo: 'APP-JKT-2026-001',
      branchCode: 'JAKARTA',
      branchName: 'Cabang Jakarta Selatan',
      customerName: 'Budi Santoso',
      customerNik: '3271012304920001',
      customerPhone: '081234567890',
      customerEmail: 'budi.santoso@gmail.com',
      province: 'DKI Jakarta',
      city: 'Jakarta Selatan',
      domicileAddress: 'Jl. Fatmawati Raya No. 12B, RT 004 / RW 002, Cilandak',
      motherMaidenName: 'Siti Aminah',
      occupation: 'Karyawan Swasta',
      jobPosition: 'Senior IT Officer',
      businessSector: 'Teknologi Informasi & Keuangan',
      companyName: 'PT BCA Finance Tbk',
      monthlyIncome: 15000000,
      fundSource: 'Gaji Bulanan Utama',
      companyPhone: '021-55443322',
      companyAddress: 'Jl. Jend. Sudirman No. 45, Jakarta Selatan',

      productName: 'Silver',
      tenorMonths: 3,
      maxPlafondLimit: 50000000,
      requestedAmount: 25000000,
      approvedAmount: 25000000,
      remainingLimit: 25000000,

      bankName: 'BCA',
      bankLogoUrl: 'https://placehold.co/120x40/00236f/ffffff?text=BCA',
      accountNumber: '1234567890',
      accountHolderName: 'Budi Santoso',
      statusCode: 'SUBMITTED',
      statusName: 'SUBMITTED',
      createdAt: '2026-09-01 09:00',
      documents: [
        {
          id: 1,
          documentType: 'Foto Selfie',
          documentName: 'Selfie_Budi.jpg',
          documentUrl: 'https://placehold.co/800x500/00236f/ffffff?text=Foto+Selfie+Budi',
          uploadedAt: '2026-09-01 08:45',
        },
        {
          id: 2,
          documentType: 'KTP Nasabah',
          documentName: 'KTP_Budi.jpg',
          documentUrl: 'https://placehold.co/800x500/00236f/ffffff?text=KTP+Budi+Santoso',
          uploadedAt: '2026-09-01 08:50',
        },
        {
          id: 3,
          documentType: 'Slip Gaji',
          documentName: 'Slip_Gaji_Budi.pdf',
          documentUrl: 'https://placehold.co/800x500/00236f/ffffff?text=Slip+Gaji+Budi',
          uploadedAt: '2026-09-01 08:52',
        },
      ],
    },
    {
      id: 102,
      loanApplicationNo: 'APP-JKT-2026-004',
      branchCode: 'JAKARTA',
      branchName: 'Cabang Jakarta Selatan',
      customerName: 'Ahmad Fauzi',
      customerNik: '3271019908910005',
      customerPhone: '081388776655',
      customerEmail: 'ahmad.fauzi@yahoo.com',
      province: 'DKI Jakarta',
      city: 'Jakarta Pusat',
      domicileAddress: 'Jl. Kebon Sirih No. 10, Gambir',
      motherMaidenName: 'Mariam',
      occupation: 'Wiraswasta',
      jobPosition: 'Owner Kuliner',
      businessSector: 'Kuliner & Restoran',
      companyName: 'Warteg Modern',
      monthlyIncome: 22000000,
      fundSource: 'Hasil Usaha Dagang',
      companyPhone: '021-33221100',
      companyAddress: 'Jl. Sabang No. 4, Jakarta Pusat',

      productName: 'Silver',
      tenorMonths: 3,
      maxPlafondLimit: 50000000,
      requestedAmount: 25000000,
      approvedAmount: 25000000,
      remainingLimit: 25000000,

      bankName: 'Mandiri',
      bankLogoUrl: 'https://placehold.co/120x40/003366/ffffff?text=Mandiri',
      accountNumber: '9988776655',
      accountHolderName: 'Ahmad Fauzi',
      statusCode: 'NEED_ADDITIONAL_DATA',
      statusName: 'NEED ADDITIONAL DATA',
      createdAt: '2026-09-01 10:15',
      documents: [],
    },
  ]);

  constructor(private fb: FormBuilder) {
    this.reviewForm = this.fb.nonNullable.group({
      notes: ['', [Validators.required, Validators.minLength(5)]],
    });
  }

  // Calendar Computations
  readonly leftCalendarMonth = computed(() => this.currentCalendarDate());
  readonly rightCalendarMonth = computed(() => {
    const d = new Date(this.currentCalendarDate());
    d.setMonth(d.getMonth() + 1);
    return d;
  });

  readonly leftDaysGrid = computed(() => this.generateDaysGrid(this.leftCalendarMonth()));
  readonly rightDaysGrid = computed(() => this.generateDaysGrid(this.rightCalendarMonth()));

  // Filter Computations
  readonly filteredQueue = computed(() => {
    const search = this.searchQuery().toLowerCase();
    const filter = this.selectedStatusFilter();
    const start = this.selectedStartDate();
    const end = this.selectedEndDate();

    return this.queueItems().filter((item) => {
      const matchesBranch = item.branchCode === this.currentBranch();
      const matchesSearch =
        item.loanApplicationNo.toLowerCase().includes(search) ||
        item.customerName.toLowerCase().includes(search) ||
        item.customerNik.includes(search);
      const matchesStatus = filter === 'ALL' || item.statusCode === filter;

      let matchesDate = true;
      const itemDate = new Date(item.createdAt);
      if (start && itemDate < this.stripTime(start)) matchesDate = false;
      if (end && itemDate > this.stripTime(end)) matchesDate = false;

      return matchesBranch && matchesSearch && matchesStatus && matchesDate;
    });
  });

  // Pagination Computations
  readonly totalItems = computed(() => this.filteredQueue().length);
  readonly totalPages = computed(() => Math.ceil(this.totalItems() / this.pageSize()) || 1);

  readonly paginatedQueue = computed(() => {
    const page = this.currentPage();
    const size = this.pageSize();
    const startIndex = (page - 1) * size;
    return this.filteredQueue().slice(startIndex, startIndex + size);
  });

  // Navigation Handlers
  goToDetailPage(item: MarketingLoanApplicationItem): void {
    this.selectedDetailItem.set(item);
    this.previewDocument.set(item.documents[0] ?? null);
    this.viewMode.set('detail');
  }

  goToTablePage(): void {
    this.viewMode.set('table');
    this.selectedDetailItem.set(null);
    this.previewDocument.set(null);
  }

  // Modal Action Handlers (Dipanggil dari Tombol di Halaman Detail)
  openActionModal(action: 'APPROVE' | 'REJECT' | 'REQUEST_ADDITIONAL_DATA'): void {
    this.currentAction.set(action);
    this.reviewForm.reset();
    this.isActionModalOpen.set(true);
  }

  closeActionModal(): void {
    this.isActionModalOpen.set(false);
    this.currentAction.set(null);
  }

  submitReview(): void {
    if (this.reviewForm.invalid) {
      this.reviewForm.markAllAsTouched();
      return;
    }

    const item = this.selectedDetailItem();
    if (!item) return;

    this.isSubmitting.set(true);
    const action = this.currentAction();

    setTimeout(() => {
      if (action === 'APPROVE') {
        this.queueItems.update((apps) =>
          apps.map((a) =>
            a.id === item.id
              ? { ...a, statusCode: 'REVIEWED', statusName: 'REVIEWED (MARKETING)' }
              : a,
          ),
        );
        alert('Pengajuan berhasil disetujui dan diteruskan ke Branch Manager!');
      } else if (action === 'REJECT') {
        this.queueItems.update((apps) =>
          apps.map((a) =>
            a.id === item.id ? { ...a, statusCode: 'REJECTED', statusName: 'REJECTED' } : a,
          ),
        );
        alert('Pengajuan telah DITOLAK.');
      } else if (action === 'REQUEST_ADDITIONAL_DATA') {
        this.queueItems.update((apps) =>
          apps.map((a) =>
            a.id === item.id
              ? { ...a, statusCode: 'NEED_ADDITIONAL_DATA', statusName: 'NEED ADDITIONAL DATA' }
              : a,
          ),
        );
        alert('Pengajuan dikembalikan ke konsumen untuk perbaikan berkas.');
      }

      this.isSubmitting.set(false);
      this.closeActionModal();
      this.goToTablePage();
    }, 500);
  }

  // Export Data CSV
  exportData(): void {
    const dataToExport = this.filteredQueue();
    if (dataToExport.length === 0) {
      alert('Tidak ada data yang dapat diexport berdasarkan filter periode saat ini.');
      return;
    }

    const headers = [
      'No Pengajuan',
      'Tanggal',
      'Cabang',
      'Nama Nasabah',
      'NIK',
      'No Telp Pemohon',
      'Email Pribadi',
      'Provinsi',
      'Kota',
      'Alamat Domisili',
      'Ibu Kandung',
      'Pekerjaan',
      'Nama Perusahaan',
      'Pendapatan Bulanan',
      'Produk',
      'Tenor (Bulan)',
      'Plafond Max',
      'Plafond Pengajuan',
      'Plafond Setujuan Final',
      'Sisa Limit',
      'Status',
    ];

    const csvRows = [headers.join(',')];

    dataToExport.forEach((item) => {
      const row = [
        `"${item.loanApplicationNo}"`,
        `"${item.createdAt}"`,
        `"${item.branchName}"`,
        `"${item.customerName}"`,
        `"${item.customerNik}"`,
        `"${item.customerPhone}"`,
        `"${item.customerEmail}"`,
        `"${item.province}"`,
        `"${item.city}"`,
        `"${item.domicileAddress}"`,
        `"${item.motherMaidenName}"`,
        `"${item.occupation}"`,
        `"${item.companyName}"`,
        item.monthlyIncome,
        `"${item.productName}"`,
        item.tenorMonths,
        item.maxPlafondLimit,
        item.requestedAmount,
        item.approvedAmount,
        item.remainingLimit,
        `"${item.statusName}"`,
      ];
      csvRows.push(row.join(','));
    });

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute(
      'download',
      `Marketing_Pengajuan_${new Date().toISOString().slice(0, 10)}.csv`,
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Calendar Helpers
  toggleDatePicker(): void {
    this.isDatePickerOpen.update((v) => !v);
  }

  prevMonth(): void {
    const d = new Date(this.currentCalendarDate());
    d.setMonth(d.getMonth() - 1);
    this.currentCalendarDate.set(d);
  }

  nextMonth(): void {
    const d = new Date(this.currentCalendarDate());
    d.setMonth(d.getMonth() + 1);
    this.currentCalendarDate.set(d);
  }

  selectDate(date: Date): void {
    const start = this.selectedStartDate();
    const end = this.selectedEndDate();

    if (!start || (start && end)) {
      this.selectedStartDate.set(date);
      this.selectedEndDate.set(null);
    } else if (start && !end) {
      if (date < start) {
        this.selectedStartDate.set(date);
      } else {
        this.selectedEndDate.set(date);
      }
    }
  }

  resetPeriode(): void {
    this.selectedStartDate.set(null);
    this.selectedEndDate.set(null);
    this.currentPage.set(1);
  }

  applyPeriode(): void {
    this.isDatePickerOpen.set(false);
    this.currentPage.set(1);
  }

  isDateSelected(date: Date): boolean {
    const start = this.selectedStartDate();
    const end = this.selectedEndDate();
    if (!start) return false;
    if (this.isSameDay(date, start)) return true;
    if (end && this.isSameDay(date, end)) return true;
    return false;
  }

  isDateInRange(date: Date): boolean {
    const start = this.selectedStartDate();
    const end = this.selectedEndDate();
    if (!start || !end) return false;
    return date > start && date < end;
  }

  private generateDaysGrid(monthDate: Date): (Date | null)[] {
    const year = monthDate.getFullYear();
    const month = monthDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const grid: (Date | null)[] = [];
    for (let i = 0; i < firstDay; i++) grid.push(null);
    for (let day = 1; day <= daysInMonth; day++) grid.push(new Date(year, month, day));
    return grid;
  }

  private isSameDay(d1: Date, d2: Date): boolean {
    return (
      d1.getFullYear() === d2.getFullYear() &&
      d1.getMonth() === d2.getMonth() &&
      d1.getDate() === d2.getDate()
    );
  }

  private stripTime(d: Date): Date {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  }

  onSearchInput(event: Event): void {
    this.searchQuery.set((event.target as HTMLInputElement).value);
    this.currentPage.set(1);
  }

  onFilterChange(): void {
    this.currentPage.set(1);
  }

  onPageSizeChange(event: Event): void {
    const newSize = Number((event.target as HTMLSelectElement).value);
    this.pageSize.set(newSize);
    this.currentPage.set(1);
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages()) {
      this.currentPage.set(page);
    }
  }

  setPreviewDocument(doc: DocumentItem): void {
    this.previewDocument.set(doc);
  }
}
